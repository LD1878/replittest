# JURO Spain SCSS Design System - Export for GitHub

This folder contains all the files from the professional UX design system, flattened for easy transfer to your GitHub repo.

## File Structure for Your Jekyll Site

Copy these files to your existing Jekyll project in the following locations:

### SCSS Files (copy to `_sass/` folder)
```
_sass/_variables.scss    - Design tokens (colors, spacing, typography)
_sass/_mixins.scss       - Reusable SCSS patterns
_sass/_base.scss         - Reset and base typography
_sass/_layout.scss       - Grid and layout utilities
_sass/_header.scss       - Navigation styles
_sass/_hero.scss         - Hero section
_sass/_buttons.scss      - Button components
_sass/_cards.scss        - Card components
_sass/_forms.scss        - Form elements
_sass/_footer.scss       - Footer styles
_sass/_animations.scss   - Animations and transitions
_sass/_utilities.scss    - Utility classes
```

### Main CSS File (copy to `assets/css/` folder)
```
assets/css/main.scss     - Main stylesheet (imports all partials)
```

### HTML Templates
```
_layouts/default.html    - Main page layout
_includes/head.html      - Document head (meta, fonts, CSS)
_includes/header.html    - Site navigation
_includes/footer.html    - Site footer with JS for mobile menu
```

## Order to Copy Files

1. **First**: Copy all 12 SCSS files to your `_sass/` folder
2. **Second**: Copy `main.scss` to your `assets/css/` folder
3. **Third**: Copy the HTML templates to their respective folders
4. **Finally**: Rebuild your Jekyll site

## Important Notes

- The SCSS uses the Inter font (loaded via Google Fonts in head.html)
- Mobile navigation requires the JavaScript in footer.html
- All colors are controlled in `_variables.scss` for easy customization
- The design uses your Spanish brand colors: Red (#E30613), Gold (#FFD700), Cream (#FFF8F0)
